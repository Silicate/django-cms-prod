=======
Credits
=======

Development Lead
----------------

* Iacopo Spalletti <i.spalletti@nephila.it>
* Kim Thoenen <kim@smuzey.ch>
* Patrick Lauber <digi@treepy.com>

Contributors
------------

* Aaron Boman
* Alexander Pervakov
* Carlo Ascani <c.ascani@nephila.it>
* Claudio Luck
* Enkel Mitrushi
* growlf
* Henning Sprang <henning.sprang@gmail.com>
* Jonas Obrist <ojiidotch@gmail.com>
* Nick Moore <nick@zoic.org>
* pipsqueaker