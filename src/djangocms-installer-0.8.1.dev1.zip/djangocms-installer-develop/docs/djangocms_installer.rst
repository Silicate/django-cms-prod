djangocms_installer package
===========================

Subpackages
-----------

.. toctree::

    djangocms_installer.config
    djangocms_installer.django
    djangocms_installer.install
    djangocms_installer.share

Submodules
----------

djangocms_installer.compat module
---------------------------------

.. automodule:: djangocms_installer.compat
    :members:
    :undoc-members:
    :show-inheritance:

djangocms_installer.main module
-------------------------------

.. automodule:: djangocms_installer.main
    :members:
    :undoc-members:
    :show-inheritance:

djangocms_installer.utils module
--------------------------------

.. automodule:: djangocms_installer.utils
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: djangocms_installer
    :members:
    :undoc-members:
    :show-inheritance:
